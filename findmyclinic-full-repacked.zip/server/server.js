import express from 'express';
import fs from 'fs';
import path from 'path';
import cors from 'cors';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;
const __dirnamex = path.resolve();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirnamex, 'frontend')));

// Simple validation helper
function isBlank(v){ return !v || !String(v).trim(); }

app.post('/api/lead', async (req, res) => {
  const { name, country, phone, treatment } = req.body || {};
  if ([name, country, phone, treatment].some(isBlank)) {
    return res.status(400).json({ ok:false, error: 'Missing fields' });
  }

  const lead = {
    id: Date.now().toString(36),
    name, country, phone, treatment,
    userAgent: req.headers['user-agent'],
    ip: req.ip,
    createdAt: new Date().toISOString()
  };

  // Persist to a JSON file
  const dbPath = path.join(__dirnamex, 'server', 'leads.json');
  let list = [];
  try {
    list = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
    if (!Array.isArray(list)) list = [];
  } catch { /* ignore */ }
  list.push(lead);
  fs.writeFileSync(dbPath, JSON.stringify(list, null, 2));

  // Optional email notification
  if (process.env.SMTP_HOST && process.env.NOTIFY_TO) {
    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: false,
        auth: process.env.SMTP_USER ? {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        } : undefined
      });
      await transporter.sendMail({
        from: process.env.MAIL_FROM || 'leads@findmyclinic.local',
        to: process.env.NOTIFY_TO,
        subject: `New Clinic Lead — ${name} (${country})`,
        text: `Name: ${name}\nCountry: ${country}\nWhatsApp: ${phone}\nTreatment: ${treatment}\n\nCreated: ${lead.createdAt}`
      });
    } catch (e) {
      console.error('Email error', e.message);
    }
  }

  return res.json({ ok:true, id: lead.id });
});

// Fallback to SPA-style index (for static single page)
app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirnamex, 'frontend', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
