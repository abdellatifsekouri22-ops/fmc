
document.addEventListener('DOMContentLoaded', () => {
  const countrySelect = document.getElementById('country');
  if (countrySelect) {
    const haveOptions = countrySelect.options && countrySelect.options.length > 1;
    if (!haveOptions) {
      const countries = ["United Kingdom","Ireland","United States","Canada","Australia","New Zealand","Germany","France","Spain","Italy","Netherlands","Belgium","Norway","Sweden","Denmark","Finland","Switzerland","Austria","Poland","Czechia","Romania","Bulgaria","Greece","Turkey","Morocco","Saudi Arabia","United Arab Emirates","Qatar","Kuwait","Bahrain"];
      countrySelect.innerHTML = '<option value="" disabled selected>Select your country</option>';
      countries.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c; opt.textContent = c;
        countrySelect.appendChild(opt);
      });
    }
  }
});

// Populate countries and handle lead submission
const countrySelect = document.getElementById('country');
const countries = ["United Kingdom","Ireland","United States","Canada","Australia","New Zealand","Germany","France","Spain","Italy","Netherlands","Belgium","Norway","Sweden","Denmark","Finland","Switzerland","Austria","Poland","Czechia","Romania","Bulgaria","Greece","Turkey","Morocco","Saudi Arabia","UAE","Qatar","Kuwait","Bahrain"];
countries.forEach(c => {
  const opt = document.createElement('option');
  opt.value = c; opt.textContent = c;
  if (c === "United Kingdom") opt.selected = true;
  countrySelect.appendChild(opt);
});

const form = document.getElementById('lead-form');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  try {
    const res = await fetch('/api/lead', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error('Failed to submit lead');
    const json = await res.json();
    alert('Thanks! We will reach out on WhatsApp shortly.');
    form.reset();
  } catch (err) {
    console.error(err);
    alert('Something went wrong. Please try WhatsApp if the form fails.');
  }
});


// --- Preview Tools ---
const btnOutline = document.getElementById('btn-outline');
const btnGrid = document.getElementById('btn-grid');
if (btnOutline && btnGrid) {
  btnOutline.addEventListener('click', () => {
    document.documentElement.classList.toggle('__debug');
  });
  btnGrid.addEventListener('click', () => {
    document.documentElement.classList.toggle('__grid-overlay');
  });
}
